import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { UsersService } from './users.service';

describe('UsersService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new UsersService();
  });

  it('should run #all()', async () => {

    service.all();

  });

  it('should run #findOne()', async () => {

    service.findOne({});
    // expect(service.users.find).toHaveBeenCalled();
  });

});
