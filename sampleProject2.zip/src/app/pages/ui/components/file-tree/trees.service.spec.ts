import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { TreesService } from './trees.service';

describe('TreesService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new TreesService();
  });

});
