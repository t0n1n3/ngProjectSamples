// tslint:disable
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { Component } from '@angular/core';
import { NotificationComponent } from './notification.component';
import { GlobalService } from '../../../../shared/services/global.service';

@Injectable()
class MockGlobalService {}

describe('NotificationComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        NotificationComponent,

      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: GlobalService, useClass: MockGlobalService }
      ]
    }).overrideComponent(NotificationComponent, {
    }).compileComponents();
    fixture = TestBed.createComponent(NotificationComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should run #constructor()', async () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {

    component.ngOnInit();

  });

  it('should run #notification()', async () => {

    component.notification({});
    // expect(component.alertMessage).toHaveBeenCalled();
  });

  it('should run #alert2Basic()', async () => {

    component.alert2Basic();

  });

  it('should run #alert2Error()', async () => {

    component.alert2Error();

  });

  it('should run #alertConfirm()', async () => {

    component.alertConfirm();

  });

  it('should run #alertTimer()', async () => {

    component.alertTimer();

  });

  it('should run #alertRequest()', async () => {

    component.alertRequest();

  });

  it('should run #alertImg()', async () => {

    component.alertImg();

  });

});
