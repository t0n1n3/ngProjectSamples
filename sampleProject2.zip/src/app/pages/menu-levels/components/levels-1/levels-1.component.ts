import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-levels-1',
  template: `<router-outlet></router-outlet>`
})
export class Levels1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
