import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { TablesDataService } from './tablesData.service';

describe('TablesDataService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new TablesDataService();
  });

});
