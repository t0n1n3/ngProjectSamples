import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { ChartsService } from './charts.service';

describe('ChartsService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new ChartsService();
  });

  it('should run #getBarOption()', async () => {

    service.getBarOption();

  });

  it('should run #getLineOption()', async () => {

    service.getLineOption();

  });

  it('should run #getPieOption()', async () => {

    service.getPieOption();

  });

  it('should run #getAnimationBarOption()', async () => {

    service.getAnimationBarOption();

  });

});
