import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-charts',
    template: `<router-outlet></router-outlet>`
})
export class ChartsComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
