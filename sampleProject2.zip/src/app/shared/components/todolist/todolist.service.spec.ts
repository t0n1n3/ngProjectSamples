import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { TodoListService } from './todolist.service';

describe('TodoListService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new TodoListService();
  });

  it('should run #getTodoList()', async () => {

    service.getTodoList();

  });

});
