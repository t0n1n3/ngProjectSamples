// tslint:disable
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { Component } from '@angular/core';
import { TodolistComponent } from './todolist.component';
import { TodoListService } from './todolist.service';

@Injectable()
class MockTodoListService {}

describe('TodolistComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        TodolistComponent,

      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: TodoListService, useClass: MockTodoListService }
      ]
    }).overrideComponent(TodolistComponent, {
    }).compileComponents();
    fixture = TestBed.createComponent(TodolistComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should run #constructor()', async () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {

    component.ngOnInit();
    // expect(component.todoListService.getTodoList).toHaveBeenCalled();
  });

  it('should run #edit()', async () => {

    component.edit({});

  });

  it('should run #overMatter()', async () => {

    component.overMatter({});

  });

  it('should run #enterTaskEdit()', async () => {

    component.enterTaskEdit({});

  });

  it('should run #cancelTaskEdit()', async () => {

    component.cancelTaskEdit({});

  });

  it('should run #creatNewTask()', async () => {

    component.creatNewTask();
    // expect(component.todolist.unshift).toHaveBeenCalled();
  });

});
