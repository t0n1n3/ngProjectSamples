// tslint:disable
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { Component } from '@angular/core';
import { TabsetComponent } from './tabset.component';
import { GlobalService } from '../../services/global.service';

@Injectable()
class MockGlobalService {}

describe('TabsetComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        TabsetComponent,

      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: GlobalService, useClass: MockGlobalService }
      ]
    }).overrideComponent(TabsetComponent, {
    }).compileComponents();
    fixture = TestBed.createComponent(TabsetComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should run #constructor()', async () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {

    component.ngOnInit();
    // expect(component._getTabMenu).toHaveBeenCalled();
  });

  it('should run #isActive()', async () => {

    component.isActive({});
    // expect(component._globalService.dataBusChanged).toHaveBeenCalled();
  });

  it('should run #_getTabMenu()', async () => {

    component._getTabMenu();
    // expect(component.tabsMenuItem.push).toHaveBeenCalled();
  });

});
