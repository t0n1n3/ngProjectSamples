export class TabMenuModel {
    for: string;
    text: string;
    active: boolean;
    disabled: boolean;
}
