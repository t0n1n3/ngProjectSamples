export class NotificationModel {
    type: string;
    title: string;
    value: string;
}
