import { async } from '@angular/core/testing';
import { Injectable } from '@angular/core';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { menuService } from './menu.service';
import { GlobalService } from './global.service';
import { Router } from '@angular/router';

@Injectable()
class MockGlobalService {}

@Injectable()
class MockRouter {
  navigate() {};
}

describe('menuService', () => {
  let service;

  beforeEach(() => {
    // @ts-ignore
    service = new menuService({}, {});
  });

  it('should run #queryParentNode()', async () => {

    service.queryParentNode({}, {});
    // expect(service.queryParentNode).toHaveBeenCalled();
  });

  it('should run #creatRouterLink()', async () => {

    service.creatRouterLink({});
    // expect(service.queryParentNode).toHaveBeenCalled();
    // expect(service.path_item.unshift).toHaveBeenCalled();
    // expect(service.creatRouterLink).toHaveBeenCalled();
  });

  it('should run #getNodePath()', async () => {

    service.getNodePath([{
      children: {},
      toggle: {},
      path: {},
      routerLink: {
        unshift: function() {}
      }
    }]);
    // expect(service.getNodePath).toHaveBeenCalled();
    // expect(service.creatRouterLink).toHaveBeenCalled();
  });

  it('should run #putSidebarJson()', async () => {

    service.putSidebarJson();

  });

  it('should run #selectItem()', async () => {

    service.selectItem([{
      routerLink: {},
      isActive: {},
      children: {}
    }]);
    // expect(service._router.isActive).toHaveBeenCalled();
    // expect(service._router.createUrlTree).toHaveBeenCalled();
    // expect(service._globalService.dataBusChanged).toHaveBeenCalled();
    // expect(service.selectItem).toHaveBeenCalled();
  });

});
