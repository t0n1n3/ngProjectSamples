import { async } from '@angular/core/testing';
import { Observable, of as observableOf, throwError } from 'rxjs';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';

import { RootComponent } from './root.component';
import { GlobalService } from '../services/global.service';
describe('RootComponent', () => {
  let obj;

@Injectable()
class MockGlobalService {}

  beforeEach(() => {
    // @ts-ignore
    obj = new RootComponent({});
  });

  it('should run #alertMessage()', async () => {

    obj.alertMessage();
    // expect(obj._globalService.dataBusChanged).toHaveBeenCalled();
  });

});
