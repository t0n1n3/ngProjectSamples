// tslint:disable
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { Component } from '@angular/core';
import { MenuComponent } from './menu.component';
import { GlobalService } from '../../services/global.service';

@Injectable()
class MockGlobalService {}

describe('MenuComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        MenuComponent,

      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: GlobalService, useClass: MockGlobalService }
      ]
    }).overrideComponent(MenuComponent, {
    }).compileComponents();
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should run #constructor()', async () => {
    expect(component).toBeTruthy();
  });

  it('should run #isToggleOn()', async () => {

    component.isToggleOn({
      toggle: {}
    });

  });

  it('should run #_selectItem()', async () => {

    component._selectItem({});
    // expect(component._globalService.dataBusChanged).toHaveBeenCalled();
  });

});
