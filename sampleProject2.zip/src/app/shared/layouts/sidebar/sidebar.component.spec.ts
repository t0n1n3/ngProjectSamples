// tslint:disable
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output, Injectable } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { Component } from '@angular/core';
import { SidebarComponent } from './sidebar.component';
import { menuService } from '../../services/menu.service';
import { GlobalService } from '../../services/global.service';

@Injectable()
class MockmenuService {}

@Injectable()
class MockGlobalService {}

describe('SidebarComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        SidebarComponent,

      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: menuService, useClass: MockmenuService },
        { provide: GlobalService, useClass: MockGlobalService }
      ]
    }).overrideComponent(SidebarComponent, {
    }).compileComponents();
    fixture = TestBed.createComponent(SidebarComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should run #constructor()', async () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {

    component.ngOnInit();
    // expect(component._menuService.putSidebarJson).toHaveBeenCalled();
    // expect(component._menuService.selectItem).toHaveBeenCalled();
    // expect(component._sidebarToggle).toHaveBeenCalled();
    // expect(component._isSelectItem).toHaveBeenCalled();
  });

  it('should run #_sidebarToggle()', async () => {

    component._sidebarToggle();

  });

  it('should run #_isSelectItem()', async () => {

    component._isSelectItem({});
    // expect(component._isSelectItem).toHaveBeenCalled();
  });

  it('should run #onResize()', async () => {

    component.onResize({});

  });

  it('should run #ngAfterViewInit()', async () => {

    component.ngAfterViewInit();

  });

});
