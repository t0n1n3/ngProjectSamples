import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-name',
  templateUrl: './component-name.component.html',
  styleUrls: ['./component-name.component.css']
})
export class ComponentNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  /**
   * 
   */
  add = (a: number, b: number): number => {
    return a + b;
  }

  sub = (numOne: number, numTwo: number): number => {
    return numOne + numTwo;
  }

  mul = (mulOne: number, mulTwo: number): number => {
    return mulOne + mulTwo;
  }

  div = (n: number, d: number): number => {
    return n / d;
  }

  callBack = (n: number, d: number) => {
    this.div(n, d);
  }

  emptyFunction = () => {

  }


}
