import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-component-one',
  templateUrl: './angular-component-one.component.html',
  styleUrls: ['./angular-component-one.component.css']
})

export class AngularComponentOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  public add() {

  }

  sub() {

  }
}
