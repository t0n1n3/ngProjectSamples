import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AngularComponentOneComponent } from './angular-component-one/angular-component-one.component';
import { AngularComponentTwoComponent } from './angular-component-two/angular-component-two.component';
import { AngularComponentThreeComponent } from './angular-component-three/angular-component-three.component';
import { ComponentNameComponent } from './component-name/component-name.component';

@NgModule({
  declarations: [
    AppComponent,
    AngularComponentOneComponent,
    AngularComponentTwoComponent,
    AngularComponentThreeComponent,
    ComponentNameComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
