import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-component-two',
  templateUrl: './angular-component-two.component.html',
  styleUrls: ['./angular-component-two.component.css']
})
export class AngularComponentTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
