import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-component-three',
  templateUrl: './angular-component-three.component.html',
  styleUrls: ['./angular-component-three.component.css']
})
export class AngularComponentThreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
