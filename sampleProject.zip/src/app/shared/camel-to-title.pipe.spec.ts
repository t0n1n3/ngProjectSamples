import { async } from '@angular/core/testing';
import { Observable, of as observableOf, throwError } from 'rxjs';

import { CamelToTitlePipe } from './camel-to-title.pipe';

describe('CamelToTitlePipe', () => {
  let pipe;

  beforeEach(() => {
    pipe = new CamelToTitlePipe();
  });

  it('should run #transform()', async () => {

    pipe.transform('value');

  });

});
