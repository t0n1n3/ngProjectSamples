# Angular/TypeScript Forms

This code sample demonstrates how Angular template-driven forms and 
reactive forms can be created and used.

## Running the Application

1. Install the Angular CLI: `npm install -g @angular/cli`

1. Run `npm install` to install app dependencies

1. Run `ng serve -o` to start the server and launch the app
